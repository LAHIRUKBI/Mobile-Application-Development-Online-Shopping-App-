package com.example.market

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class success : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_success)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize the finish button and set click listener
        val finishButton: Button = findViewById(R.id.finishButton)
        finishButton.setOnClickListener {
            // Create intent to navigate to HomeActivity
            val intent = Intent(this, Home::class.java) // Ensure the HomeActivity class name is correct
            startActivity(intent)
            // Optional: Finish the current activity to prevent returning to it
            finish()
        }
    }
}