package com.example.market

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Set click listeners for Buy buttons
        findViewById<Button>(R.id.buyButton1).setOnClickListener {
            navigateToPayment("Eco-Friendly Cloth Bag")
        }
        findViewById<Button>(R.id.buyButton2).setOnClickListener {
            navigateToPayment("Eco-Friendly Vask")
        }
        findViewById<Button>(R.id.buyButton3).setOnClickListener {
            navigateToPayment("Eco-Bag")
        }
        findViewById<Button>(R.id.buyButton4).setOnClickListener {
            navigateToPayment("Eco-Bag")
        }
        findViewById<Button>(R.id.buyButton5).setOnClickListener {
            navigateToPayment("Eco-Bag")
        }
        // Set click listener for profile image
        findViewById<ImageView>(R.id.profileImageView).setOnClickListener {
            navigateToProfile()
        }
    }

    private fun navigateToPayment(itemName: String) {
        val intent = Intent(this, Payment::class.java)
        intent.putExtra("ITEM_NAME", itemName)
        startActivity(intent)
    }

    private fun navigateToProfile() {
        val intent = Intent(this, login::class.java)
        startActivity(intent)
    }
}